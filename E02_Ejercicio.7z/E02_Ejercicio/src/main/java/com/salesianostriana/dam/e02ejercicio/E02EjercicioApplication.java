package com.salesianostriana.dam.e02ejercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E02EjercicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(E02EjercicioApplication.class, args);
	}

}
