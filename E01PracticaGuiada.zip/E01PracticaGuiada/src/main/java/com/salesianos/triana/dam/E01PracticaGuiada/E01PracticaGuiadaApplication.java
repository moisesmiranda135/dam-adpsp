package com.salesianos.triana.dam.E01PracticaGuiada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E01PracticaGuiadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(E01PracticaGuiadaApplication.class, args);
	}

}
