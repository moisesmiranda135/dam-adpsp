package com.salesianos.triana.dam.E01PracticaGuiada.errors.models;

public abstract class ApiSubError {
}
