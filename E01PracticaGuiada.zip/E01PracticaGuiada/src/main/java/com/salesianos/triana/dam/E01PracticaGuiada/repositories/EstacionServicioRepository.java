package com.salesianos.triana.dam.E01PracticaGuiada.repositories;

import com.salesianos.triana.dam.E01PracticaGuiada.models.EstacionServicio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstacionServicioRepository extends JpaRepository<EstacionServicio, Long> {

    boolean existsByUbicacion(String nombre);
}
