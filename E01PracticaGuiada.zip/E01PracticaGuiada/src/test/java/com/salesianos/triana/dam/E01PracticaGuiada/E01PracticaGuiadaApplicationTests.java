package com.salesianos.triana.dam.E01PracticaGuiada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E01PracticaGuiadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
