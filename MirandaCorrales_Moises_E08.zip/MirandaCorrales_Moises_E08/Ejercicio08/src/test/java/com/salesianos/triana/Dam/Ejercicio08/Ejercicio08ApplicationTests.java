package com.salesianos.triana.Dam.Ejercicio08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
