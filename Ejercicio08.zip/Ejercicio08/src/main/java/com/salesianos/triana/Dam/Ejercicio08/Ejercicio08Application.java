package com.salesianos.triana.Dam.Ejercicio08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio08Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio08Application.class, args);
	}

}
